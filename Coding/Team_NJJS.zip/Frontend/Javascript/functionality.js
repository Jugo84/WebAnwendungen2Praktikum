// slide-show
$(document).ready(function(){   
    $('.carousel').carousel({
        interval: 1000 * 10
      });
 })

 
